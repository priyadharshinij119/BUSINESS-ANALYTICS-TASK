Highest-performing combination

Technology – Phones is the highest-performing Category–Sub-Category combination, showing one of the darkest color intensities in the Heat Map. This indicates that Phones generate the highest sales among the product combinations.

 
 Lowest-performing combination

Office Supplies – Fasteners is the lowest-performing combination, represented by a very light color in the Heat Map. This indicates comparatively low sales.

3. Categories with consistently high/low values
Technology shows consistently strong performance, particularly in Phones, Copiers, and Machines.
Furniture has mixed performance, with Chairs performing strongly while some other sub-categories have lower sales.
Office Supplies contains several lower-sales sub-categories, particularly Fasteners, Labels, and Envelopes.


 Noticeable patterns

The Heat Map shows that sales are not evenly distributed across all product combinations. Technology contains several high-performing sub-categories, while Office Supplies has more low-to-medium performing sub-categories. Within Furniture, some products such as Chairs perform strongly while others contribute less to sales.

 
 
 Business Insights
1 – Technology has strong sales performance

Technology products contribute significantly to overall sales, with Phones being particularly strong.

2 – Phones are an important product category

The high sales of Phones indicate strong customer demand and make them an important contributor to business revenue.

3 – Furniture performance is mixed

Furniture contains both high- and lower-performing sub-categories. Chairs show strong sales, while other Furniture products have comparatively lower values.

 4 – Office Supplies has several low-performing products

Sub-categories such as Fasteners, Labels, and Envelopes have relatively low sales compared with the strongest products in Technology and Furniture.

 5 – Sales vary considerably by sub-category

The Heat Map demonstrates that business performance depends strongly on the specific sub-category rather than only the main category. Therefore, analyzing products at a detailed level can reveal opportunities that would be hidden by looking only at total category sales.



 Business Recommendations
 1 – Focus on high-performing products

The business should maintain sufficient inventory and marketing support for high-performing products such as Phones and Chairs. Promotions and product availability can be prioritized for products that consistently generate higher sales.

 2 – Analyze and improve low-performing products

The business should investigate low-performing products such as Fasteners, Labels, and Envelopes. Factors such as pricing, discounts, customer demand, product placement, and regional demand should be analyzed before deciding whether to increase promotions, change pricing, or reduce inventory.

https://public.tableau.com/views/week10task_17903101632760/Dashboard1?:language=en-US&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link
